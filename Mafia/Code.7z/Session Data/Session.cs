﻿namespace Libs
{
    public class Session
    {
        public Dictionary<string, object> State { get; } = new();
    }
}